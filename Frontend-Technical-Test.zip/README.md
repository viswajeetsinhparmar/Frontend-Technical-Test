# Frontend-Technical-Test
Highlight the Input field(s) based on operation from Button click.

### Prerequisites

- Basic knowledge about javascript, react, HTML, CSS etc.

### Installing

Please run `npm install` to get required packages

You can also update the packages by `npm update`

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details
